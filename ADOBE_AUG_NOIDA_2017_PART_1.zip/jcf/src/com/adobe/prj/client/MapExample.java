package com.adobe.prj.client;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapExample {

	public static void main(String[] args) {
		Map<String, Integer> bookMap = new HashMap<String,Integer>();
		bookMap.put("Java", 100);
		bookMap.put("NodeJS", 300);
		bookMap.put("Angular", 30);
		bookMap.put("Java", 700); // overwrite the entry
		
		System.out.println(bookMap.get("NodeJS"));
		System.out.println(bookMap.get("Java"));
		
		System.out.println("Traverse using keys");
		Set<String> keys = bookMap.keySet();
		for(String key : keys) {
			System.out.println(key + "  : " + bookMap.get(key));
		}
		
		System.out.println("****");
		
		for(Entry<String, Integer> entry : bookMap.entrySet()) {
				System.out.println(entry.getKey() + " : " + entry.getValue());
		}
	}

}
