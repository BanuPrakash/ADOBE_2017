package com.adobe.prj.client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.adobe.prj.entity.Product;

public class SetFirstExample {

	public static void main(String[] args) {
		Set<Product> products = new HashSet<Product>() ;
//		Set<Product> products = new TreeSet<Product>() ;
		/*Set<Product> products = new TreeSet<Product>(new Comparator<Product>() {
			@Override
			public int compare(Product o1, Product o2) {
					return Double.compare(o1.getPrice(), o2.getPrice());
			}
		}) ;*/
		
		products.add(new Product(124,"HP Spectre",120000.00,"computer"));
		products.add(new Product(452,"iPhone 7", 72000.00,"mobile"));
		products.add(new Product(100,"Moto G", 12000.00,"mobile"));
		products.add(new Product(80,"Samsung UHD", 152000.00,"tv"));
		products.add(new Product(700,"Logotech", 500.00,"computer"));
		products.add(new Product(452,"iPhone 7", 72000.00,"mobile"));
	
		System.out.println("*********");
		System.out.println("for each");
		for(Product p : products) {
			System.out.println(p.getId() +","  + p.getName() + ", " + p.getPrice());
		}
		System.out.println("*********");
		System.out.println("Iterator");
		Iterator<Product> iter = products.iterator();
		while(iter.hasNext()) {
			Product p = iter.next();
			if(p.getCategory().equals("mobile")) {
				iter.remove();
			}
			System.out.println(p.getId() +","  + p.getName() + ", " + p.getPrice());
		}
		
		List<Product> list = new ArrayList<Product>(products);
		
	}
	
	public void add(List<Product> products) {
		
	}

}
