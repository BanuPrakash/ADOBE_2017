package com.adobe.prj.client;

import com.adobe.prj.entity.Product;

public class Identitycode {

	public static void main(String[] args) {
		// hascode story
		String s1 = "Aa";
		String s2 ="BB";
		String s3 = "AA";
		String s4 = "aa";
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
		
		System.out.println(s1.equals(s2));
		
		Product p1 = new Product(452,"iPhone 7", 72000.00,"mobile");
		Product p2 = new Product(452,"iPhone 7", 72000.00,"mobile");
		Product p3 = p1;
		if(p1 == p3) {
			System.out.println("p1 and p3 are same");
		}
		if(p1 == p2) {
			System.out.println("p1 and p2 are same");
		}
		if(p1.equals(p2)) {
			System.out.println("p1 and p2 content is  same");
		}
	}

}
