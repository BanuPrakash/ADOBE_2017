package com.adobe.prj.util;

public interface IComparable {
	int difference(Object other);
}
