package com.adobe.prj.client;

import com.adobe.prj.entity.Book;
import com.adobe.prj.util.SQLParser;

public class ORMClient {

	public static void main(String[] args) {
		String INSERT_SQL = SQLParser.generateCreateSQL(Book.class);
		System.out.println(INSERT_SQL);
		
		Book b = new Book(23,"Java Ref",450.55);
		
		System.out.println(SQLParser.generateInsertSQL(b));
	}

}
