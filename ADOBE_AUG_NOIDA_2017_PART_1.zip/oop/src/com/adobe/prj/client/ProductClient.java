package com.adobe.prj.client;

import javax.rmi.CORBA.Util;

import com.adobe.prj.entity.Mobile;
import com.adobe.prj.entity.Product;
import com.adobe.prj.entity.Tv;
import com.adobe.prj.util.Utility;

public class ProductClient {

	public static void main(String[] args) {
		Product[] products = new Product[4];
		products[0] = new Mobile(1, "iPhone 7", 72000.00, "4G");
		products[1] = new Tv(2, "Onida Thunder", 3500.00, "CRT");
		products[2] = new Mobile(3, "Moto G", 12000.00, "4G");
		products[3] = new Tv(4, "Sony", 83500.00, "LED");
		// products[4] = new Product(5,"Dummy",0.0);
		
		Utility.sort(products);
		
		for (int i = 0; i < products.length; i++) {
			System.out.println(products[i].getName() + ", " + products[i].getPrice());
			if (products[i].isExpensive()) {
				System.out.println("Product is expensive ");
			} else {
				System.out.println("Product is not expensive");
			}
			if (products[i] instanceof Mobile) {
				Mobile m = (Mobile) products[i];
				System.out.println(m.getConnectivity());
			} else if(products[i].getClass() == Tv.class) { //strict
				Tv t = (Tv) products[i];
				System.out.println(t.getScreenType());
			}
		}
	}

}
