package com.adobe.prj.client;

import com.adobe.prj.entity.Account;

public class AccountClient {

	public static void main(String[] args) {
		Account rahulAcc = new Account();
		System.out.println(Account.getCount()); // 1
		Account swethaAcc = new Account();
		System.out.println(Account.getCount()); // 2
		
		rahulAcc.deposit(2500.00);
		swethaAcc.deposit(3500.00);
		
		swethaAcc.withdraw(1200.00);
		
		System.out.println("First Account status:");
		System.out.println(rahulAcc.getBalance());
		
		System.out.println("Second Account status:");
		System.out.println(swethaAcc.getBalance());
	}

}
