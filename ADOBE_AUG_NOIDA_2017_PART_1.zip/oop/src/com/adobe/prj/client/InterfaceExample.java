package com.adobe.prj.client;

import com.adobe.prj.dao.DaoFactory;
import com.adobe.prj.dao.MobileDao;
import com.adobe.prj.entity.Mobile;

public class InterfaceExample {

	public static void main(String[] args) {
		Mobile m = new Mobile(1, "iPhone 7", 72000.00, "4G");
//		MobileDao mobileDao = new MobileDaoDbImpl();
		MobileDao mobileDao = DaoFactory.getMobileDao();
		mobileDao.addMobile(m);
	}

}
