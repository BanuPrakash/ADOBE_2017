package com.adobe.prj.dao;

import java.util.ResourceBundle;

public class DaoFactory {
	private static String DAO_CLASS_NAME = "";
	
	static {
		ResourceBundle res = ResourceBundle.getBundle("database");
		DAO_CLASS_NAME = res.getString("MOBILE_DAO");
	}
	
	public static MobileDao getMobileDao() {
		try {
			return (MobileDao) Class.forName(DAO_CLASS_NAME).newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
}
