package com.adobe.prj.dao;

import com.adobe.prj.entity.Mobile;

public class MobileDaoFileImpl implements MobileDao {

	@Override
	public void addMobile(Mobile mobile) {
		System.out.println(mobile.getName() + " stored in file system...");
	}

}
