package com.adobe.prj.entity;

import com.adobe.prj.annotations.Column;
import com.adobe.prj.annotations.Table;
@Table(name="books")
public class Book {
	private int bookId;
	private String title;
	private double price;

	public Book() {
	}

	public Book(int bookId, String title, double price) {
		this.bookId = bookId;
		this.title = title;
		this.price = price;
	}
	@Column(name="book_id", type="numeric(12)")
	public int getBookId() {
		return bookId;
	}
	@Column(name="book_title")
	public String getTitle() {
		return title;
	}
	@Column(name="cost", type="numeric(15,2)")
	public double getPrice() {
		return price;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
