/**
 * 
 */
package com.adobe.prj.entity;

/**
 * entity class to represent business account data.
 *  
 * @author Banu Prakash
 * @since 1.0
 * @version 1.0
 */
public class Account {
	private double balance; //state of object ==> instance variables
	
	private static int count; //state of class [class data] 
	
	public Account() {
		count++;
	}
	/**
	 * method to credit amount into account.
	 * 
	 * @param amt amount to credit
	 */
	public void deposit(double amt) {
		balance += amt;
	}
	
	/**
	 * method to debit amount from account
	 * 
	 * @param amt amount to be debited
	 */
	public void withdraw(double amt) {
		balance -= amt;
	}
	/**
	 * method to get balance status
	 * 
	 * @return the current balance
	 */
	public double getBalance() {
		return balance;
	}
	
	public static int getCount() {
		return count;
	}
}
