package com.adobe.prj.dao;

import java.util.List;

import com.adobe.prj.entity.Movie;

public interface MovieDao {
	List<Movie> getMovies() throws FetchException;
	void addMovie(Movie movie) throws PersistenceException;
	void deleteMovie(int id);
}
