package com.adobe.prj.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.adobe.prj.dao.FetchException;
import com.adobe.prj.dao.MovieDao;
import com.adobe.prj.dao.PersistenceException;
import com.adobe.prj.entity.Movie;

public class MovieDaoJdbcImpl implements MovieDao {

	public List<Movie> getMovies() throws FetchException {
		List<Movie> movies = new ArrayList<Movie>();
		Connection con = null;

		try {
			con = DBUtil.getConnection();
			// code
		} catch (SQLException e) {
			throw new FetchException("unable to get movies", e);
		} finally {
			DBUtil.closeConnection(con);
		}
		return movies;
	}

	public void addMovie(Movie movie) throws PersistenceException {
		String SQL = "INSERT INTO movies VALUES(0,?,?)";
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.setString(1, movie.getTitle());
			ps.setDate(2, new java.sql.Date(movie.getReleaseDate().getTime()));
			ps.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException("unable to add movie:" + movie.getTitle(), e);
		} finally {
			DBUtil.closeConnection(con);
		}
	}

	public void deleteMovie(int id) {
		// TODO Auto-generated method stub

	}

}
