package com.adobe.prj.dao.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	
	private static String DRIVER = DBConfig.getString("DRIVER"); //$NON-NLS-1$
	private static String URL = DBConfig.getString("URL"); //$NON-NLS-1$
	private static String USER = DBConfig.getString("USER"); //$NON-NLS-1$
	private static String PWD = DBConfig.getString("PASSWORD"); //$NON-NLS-1$

	static {
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(URL,USER,PWD);
	}
	
	public static void closeConnection(Connection con) {
		if( con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
