package com.adobe.prj.client;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.adobe.prj.dao.MovieDao;
import com.adobe.prj.dao.PersistenceException;
import com.adobe.prj.dao.jdbc.MovieDaoJdbcImpl;
import com.adobe.prj.entity.Movie;

public class InsertMovie {

	public static void main(String[] args) {
		MovieDao movieDao = new MovieDaoJdbcImpl(); // use factory class 
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String strDate = "10-12-1983";
		Date d = null;
		try {
			d = sdf.parse(strDate);
			Movie m = new Movie(0,"Flash Dance", d);
			movieDao.addMovie(m);
			System.out.println("Movie added successfully!!!");
		} catch (ParseException e) {
			e.printStackTrace();
		}catch (PersistenceException e) {
			e.printStackTrace();
		}
	}
}
