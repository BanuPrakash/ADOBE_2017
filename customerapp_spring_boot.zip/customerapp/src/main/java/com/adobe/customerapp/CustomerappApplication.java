package com.adobe.customerapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerappApplication.class, args);
	}
}
