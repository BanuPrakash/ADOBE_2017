/*
	New Collection APIs
	Set, Map,WeakSet
*/

// Set is a collection of unique elements

var s = new Set();

s.add(10);
s.add(12);
s.add(15);
s.add(10); // not added because of duplicate

for(let data of s) {
	console.log(data);
}

var map = new Map();
map.set("Java",345.55);
map.set("JavaScript",134.00);

for( [k,v] of map.entries()) {
	console.log(k +" ----> " + v);
}

for( key of map.keys()){
	console.log(key + "   " + map.get(key));
}