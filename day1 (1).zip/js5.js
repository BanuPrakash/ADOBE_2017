
/*
	generators
*/

function* iter() {
	yield 10;
	yield "Smith";
}

var myiter = iter();

myiter.next()
//Object {value: 10, done: false}