/*
	class
*/

class Person {
	constructor(name, age) {
		this.name = name;
		this.age = age;
	}

	getDetails() {
		return this.name + ", " + this.age;
	}

	set Name(n) {
		this.name = n;
	}

	get Name() {
			return this.name;	
	}
}

var p = new Person("A",52);
p.Name = "Smith";
console.log(p.getDetails());
console.log(p.Name);