/*
	ES 2015
	concept of block level variables

	ES5 has only two scopes : function, global
*/

var g = 100;

const PI = 3.14159;

function test() {
	let one = 10;
	if(one > 5) {
		let two = 20; // block level
	}
	console.log(one); // two is not visible
}

test();