/*
	Iterable
*/

var elements = [3,5,72,66,2];

var name = "Rachel Green";

for(let data of elements) {
	console.log(data);
}

for(let data of name) {
	console.log(data);
}

var iter = name[Symbol.iterator]();

console.log(iter.next());
