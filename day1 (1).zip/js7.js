/**
	Promise API
	
	Synchronous call

	var result = doTask();

	Asynhronous call

	doTask().then(function(){
		success code
	},	
	function(){
		error code
	})
	.catch(e){
		// exception code
	};
*/

var doTask =  function(){
				return new Promise(function(resolve, reject){
					setTimeout(function(){
						resolve("RESTful service output");
					}, 1000);
				});
}

doTask().then(function(msg){
	console.log("Success : "+ msg);
},
function(err){
	console.log("Error : "+ msg);
});

var doSecondTask =  function(data){
				return new Promise(function(resolve, reject){
					setTimeout(function(){
						resolve("Second "  + data);
					}, 1000);
				});
}

doTask().then(doSecondTask).then(function(res){
	console.log(res);
});

//var result = Promise.all[doTask, doSecondTask];
