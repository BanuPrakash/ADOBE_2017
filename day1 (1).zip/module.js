
// import {date, shortDate} from './datelib';
// import {*} as datemodule from './datelib';
// datemodule.date
console.log(date);

console.log(shortDate());

