/*
	Deconstructing and spread operator [...]
*/

var colors = ["red","green","blue","orange","pink"];

// Old way

var red = colors[0];
var green = colors[1];

// ES6 way [deconstructing]

var [r,g,b,...others] = colors;

console.log(r);
console.log(others);

var person = {
	firstName : "Tim",
	age : 53
}

var {firstName, age} = person;

console.log(firstName);

