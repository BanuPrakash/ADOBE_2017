/**
	Arrow operator
*/

// old way 

var add = function(x, y){
	return x+y;
}

// ES6 way using Arrow operator

var sub = (x, y) => {
	return x - y;
}

console.log(sub(42,2));

var elements = [3,5,72,66,2];
var total = 0;
//old way

/*elements.forEach(function(data){
	total += data;
});

console.log(total);*/

// Es6
elements.forEach( data => total += data);
console.log(total);