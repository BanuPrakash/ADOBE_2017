var subject = {
	observers : [],
	subscribe: function(eventName, fn) {
		this.observers[eventName] = this.observers[eventName] || [];
		this.observers[eventName].push(fn);
	},
	notify: function(eventName, data) {
		this.observers[eventName].forEach(function(fn){
			fn(data);
		});
	},
	unsubscribe: function(eventName, fn) {
		// code
	}
};

// form module
(function() {
	var btn = document.getElementById("addBtn");
	var products = [ {"id": 1,"name" : "A"}, {"id": 2,"name" : "B"}];
	btn.addEventListener("click", function() {
		var obj = new Object();
		obj.id =  document.getElementById("id").value;
		obj.name = document.getElementById("name").value;
		products.push(obj);
		subject.notify("add_event",products);
	});
})();

//stats Module

(function() {
	var div = document.getElementById("stats");
	function _render(data){
		div.innerHTML = "#" + data.length;
	}
	subject.subscribe("add_event", _render);
})();

//list Module

(function() {
	var div = document.getElementById("listView");
	function generate(data){
		 var content ="";
		 div.innerHTML = "";
		 data.forEach(function(p){
		 	content += p.id +"," + p.name  +"<br />";
		 });
		 div.innerHTML = content;
	}
	subject.subscribe("add_event", generate);
})();