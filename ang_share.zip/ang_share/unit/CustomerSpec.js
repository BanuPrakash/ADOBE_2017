describe('customer controller tests', function() { 
	var scope, controller;
	beforeEach(module("customer_module"));

	beforeEach(inject(function($controller, $rootScope){
		scope = $rootScope.$new();
		controller = $controller("CustomerListController",  {
			$scope : scope
		});
	}));

	it('should get customer list', function() {
		expect(scope.customers.length).toEqual(5);
	});

	it('should delete a customer', function() {
		scope.deleteCustomer(2);
		expect(scope.customers.length).toEqual(4);
		scope.deleteCustomer(535);
		expect(scope.customers.length).toEqual(4);
	});
});
    