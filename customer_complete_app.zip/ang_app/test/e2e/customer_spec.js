describe('Protractor Demo App', function() {

  var customerList = element.all(by.repeater('customer in customers'));
 
  beforeEach(function() {
    browser.get('http://localhost:3000/first.html');
  });

  it('should have 5 customers', function() {
     expect(customerList.count()).toEqual(5);
   //  browser.pause();
  });

   it('should delete a customer', function() {
    customerList.get(2).element(by.css('.cardClose')).click();
    browser.pause();
    expect(customerList.count()).toEqual(4);
  });

});