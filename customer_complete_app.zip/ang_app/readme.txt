
Angular JS 1.5
--------------

Single Page Application [SPA] and Responsive Web Design [ RWD ]

1) Data binding
	a) one way binding
	b) two way binding

2) Dependency Injection ( Inversion of Control )
3) Routing
	Routers

	http://zomato.com/indian	

	http://zomato.com/tai

	http://zomato.com/indian/tandoor

	http://zomato.com/indian/tandoor/120

4) Cache templates

----------------


JS Frameworks 
1) Backbone
2) AngularJS
3) AngularJS2
4) ReactJS
5) Ember
6) ExtJS
7) Knockout

----------------------------------------------------------------


	node js installation

	node --version

	I am using node for module dependencies

	npm install -g bower

	bower search jquery
	
	bower install --save jquery#2
	bower install  --save bootstrap
	bower install --save angular#1.5
	



https://github.com/BanuPrakash/ADOBE_2017

----------------------

Angular JS 1.x
--------------
	Modules:

	1) controller
	2) service/factory/provider
	3) directive
	4) filter
	5) config

---------------
	var ng = angular.module("customer_module",[]);

	var ng = angular.module("sample_module",["customer_module"]);

	ng.controller("SampleController", function($scope){
		$scope.data = "Hello World";
		$scope.doTask = function() {
			$scope.data = "Good Day!!!";
		}
	});


	HTML file

	<body ng-app="sample_module">
		<div ng-controller="SampleController">
			{{data}}
			<a href="#" ng-click="doTask()">task</a>
		</div>
	</body>





	ang_app / app / controller / customer.ctrl.js


---------
 e2E is done using Protractor [ wrapper on selenium ] for angularJS

 npm -g unistall protractor

 npm clear cache

 npm -g install protractor@4

 webdriver-manager update


 npm install -g json-server


 $ json-server --watch data.json --static . --port 3000



 Directives:
 1) Built-in
 	ng-app, ng-controller, ng-repeat, ng-model, ng-if, ng-show, ng-hide
 	ng-click, ...

  2) custom directives

  		<customer></customer>

  		Why?
  		a) Modularity
  		b) testable
  		c) reusability

  		<div class="col-md-4 col-lg-3" ng-repeat="customer in customers">
            <card-view></card-view>
        </div>


        <div class="col-md-4 col-lg-3" ng-repeat="message in messages">
            <card-view></card-view>
        </div>


        <div class="col-md-4 col-lg-3" ng-repeat="product in products">
            <card-view></card-view>
        </div>






