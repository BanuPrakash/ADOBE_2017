
var mongoose = require('mongoose');
 
mongoose.connect('mongodb://localhost/my_db');

var SalesSchema = mongoose.Schema({
    category    : String,
    product     : String,
    sales      : Number,
    quarter      : Number
});

// mapping "sales" collection to our "SalesSchema"
var Sales = mongoose.model("sales", SalesSchema);

Sales.find({},function(err, docs){
	docs.forEach(function(sale){
		console.log(sale.category + ", " + sale.sales);
	});
	mongoose.disconnect();
});
