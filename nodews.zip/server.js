var http = require('http');

var fs = require('fs');

var server = http.createServer(function(request, response) {
	response.writeHead(200,{"Content-type": "text/plain"});
	// response.end("HGsfsd..");
	var stream = fs.createReadStream('fs1.js');

	stream.on('data', function(chunk){
		 response.write(chunk);
	});

	stream.on('end', function(){
		 response.end();
	});
});

server.listen(8000, function() {
	console.log("Server started [http://localhost:8000]");
});


 