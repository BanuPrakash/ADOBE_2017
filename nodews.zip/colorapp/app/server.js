var converter = require('./converter');
var http = require('http');
var url = require('url');

// http://localhost:8000/rgbToHex?red=200&green=100&blue=0
 // http://localhost:8000/hexToRgb?hex=ff0122

var server = http.createServer(function(request, response) {
	response.writeHead(200,{"Content-type": "text/plain"});
	var path = url.parse(request.url).pathname; // / /rgbToHex or /hexToRgb
	var query = url.parse(request.url, true).query; // red=200&green=100&blue=100
	if(path.substring(1) == 'rgbToHex')	 {
		var result = converter.rgbToHex(parseInt(query.red), 
			parseInt(query.green), parseInt(query.blue));
		response.end(result);
	} else if( path.substring(1) == 'hexToRgb' ) {
		var result = converter.hexToRgb(query.hex);
		response.end(JSON.stringify(result));
	}
});

server.listen(8000, function() {
	console.log("Server started [http://localhost:8000]");
});
