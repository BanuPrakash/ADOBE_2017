var converter = require('../app/converter');
var expect = require('chai').expect;

//Assemble your tests
describe('testing converter', function() { 
	// test spec
	it('test rgb to hex', function() {
		var hex = converter.rgbToHex(255,0,0);
		expect("ff0000").to.equal(hex);
	});

	// test spec
	it('test hex to rgb', function() {
		var rgb = converter.hexToRgb("ffff00");
		expect(rgb).to.be.deep.equal([255,255,0]);
	});
});