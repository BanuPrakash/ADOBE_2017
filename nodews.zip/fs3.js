
var fs = require('fs');

var content = "";

var stream = fs.createReadStream('fs1.js');

stream.on('data', function(chunk){
	console.log("chunk :" + chunk.toString());
	content += chunk;
});

stream.on('end', function(){
	console.log("Chunk " + content);
});


console.log("OUTSIDE: " + content.toString());