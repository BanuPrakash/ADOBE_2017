var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var SalesSchema = mongoose.Schema({
    category    : String,
    product     : String,
    sales      : Number,
    quarter      : Number
});

var Sales = mongoose.model("sales", SalesSchema);

/* GET home page. */
router.get('/', function(req, res, next) {
	Sales.find({},function(err, docs){
 		 res.render('sales', { sales:docs, title: "Sales Page"});
 	});
});

module.exports = router;
