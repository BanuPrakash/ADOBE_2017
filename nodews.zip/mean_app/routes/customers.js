var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');

var CustomerSchema = mongoose.Schema({
    id    : Number,
    firstName     : String,
    lastName     : String,
    gender     : String,
    address     : String
});

var Customers = mongoose.model("customers", CustomerSchema);


/* GET users listing. */
router.get('/', function(req, res, next) {
  	Customers.find({},function(err, docs){
 		 res.json(docs);
 	});
});

/* GET single user based on id. */
router.get('/:id', function(req, res, next) {
  	Customers.find({id:req.params.id},function(err, docs){
 		 res.json(docs);
 	});
});

/* Delete customer */
router.delete('/:id', function(req, res, next) {
  	 Customers.remove({id:req.params.id});
});


module.exports = router;
