(function() {
	var ng = angular.module("customer_module",[]);
	ng.controller("CustomerListController",function($scope){
		
		$scope.editCustomer = function(customer){
			$scope.currentCustomer = customer;
			$scope.editMode = true;
		}

		$scope.update = function() {
			// send data to server
			$scope.editMode = false;
		}

		$scope.deleteCustomer = function(id){
			var idx = -1;
			$scope.customers.forEach(function(c,index){
				if(c.id == id) {
					idx = index;
				}
			});
			if(idx != -1) {
				$scope.customers.splice(idx,1);
			}
		};

		$scope.customers = [
    { "id":1,
      "firstName":"Rachel",
      "lastName":"Green",
      "gender":"female",
      "address":"some address"
    },
    { "id":2,
      "firstName":"Chandler",
      "lastName":"Bing",
      "gender":"male",
      "address":"West Street"
    },
    { "id":3,
      "firstName":"Joey",
      "lastName":"Tribuanni",
      "gender":"male",
      "address":"some address"
    },
    { "id":4,
      "firstName":"Monica",
      "lastName":"Geller",
      "gender":"female",
      "address":"some address"
    },
    { "id":5,
      "firstName":"Ross",
      "lastName":"Geller",
      "gender":"male",
      "address":"some address"
    }
  ];
	})
})(); 