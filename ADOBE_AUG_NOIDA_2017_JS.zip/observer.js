var subject = {
    observers: {},

    subscribe: function(event, fn) {
        this.observers[event] = this.observers[event] || [];
        this.observers[event].push(fn);
    },

    notify: function(event, data) {
        this.observers[event].forEach(function(fn) {
            fn(data);
        })
    }
};

// List Module
(function() {
    var div = document.getElementById("listView");

    function render(data) {
        var content = "<ul>";
        data.forEach(function(prd) {
            content += "<li>" + prd.name + "</li>";
        });
        content += "</ul>";
        div.innerHTML = content;
    }
    subject.subscribe("add_event", render);
})();

// stats Module
(function() {
    var div = document.getElementById("statsView");

    function render(data) {
        div.innerHTML = "#" + data.length;
    }
    subject.subscribe("add_event", render);
})();


//form module

(function() {
	var products = [{ "id": 1, "name": "A" }, { "id": 2, "name": "B" }];
    function doTask() {
        var id = document.getElementById("id").value;
        var name = document.getElementById("name").value;
        products.push({ "id": id, "name": name });
        subject.notify("add_event", products);
    }

    document.getElementById("addBtn").addEventListener("click",doTask);

})();