
	Web technologies
	----------------

	Softwares Required 
	For Day 1:
	1) Chrome Web Browser
	2) Sublime Text 3
	3) Visual Studio Code [ TypeScript / Angular 2]
---------------------------------------------------------

	JavaScript
	----------

		Scripting language, loosely typed language

		Different types of data:
		number, boolean, string, arrays, objects , undefined, null

		We have only one keyword to declare a variable "var"

		var name = "Smith";

		var age = 24

		var employed = false;

	JavaScript executes with a JavaScript engine
		1) V8	===> Google ===> used in Chrome and NodeJS env
		2) SpiderMonkey / IonMonkey ===> FireFox
		3) Chakra	===? iE
		4) Continumm ===> Edge Browser
		5) Nashhorn ===> Java 8
	-----------------------------------------

	functions
	----------

	1) How to declare a function:
	function functionName(araguments) {

	}

	function add(x,y) {
		return x + y;
	}

	var result = add(4,5); // 9

	function add(x,y) {
		console.log("Result " + (x + y));
	}

	var result = add(4,5); // undefined

	2) Function expression

	var oper;

	if(condition) {
		oper = function(){

		}
	} else {
		oper = function() {

		}
	}

	oper();




	3) Functions are instance of "Function" type

		var add = new Function("x","y", "return x + y");
		adD(4,5); // 9

		same as :
		function add(x,y) {
			return x + y;
		}

	variable scopes:

	a.js
	----
	var g = 120; // global variable

	function first() {
		var one = 10;
		if(one > 5) {
			var two = 20;// hoisted to functional level scope
			three = 30; // hoisted to global level scope [ because "var" is not used]
			console.log(g, one, two, three); // all are visible
		}

		console.log(g, one, two, three); // g, one, two (Y), three (Y)
	}
	first();
	console.log(g, one, two, three); // g, three
-----------------------------------------------------------------------

	Functional style of programming using JavaScript

	OOP: we write methods which work on the state of object, hence they are tightly coupled
		to objects

	Commonly used functions for functional style of programming:
	1) map
	2) filter
	3) reduce
	4) iterate


	1) Pure Function
		for a given input, we expect the same output for n-calls
		add()
	2) High Order Function
		a) Functions which accept other functions as arguments
		b) functions which return a function

	---------------------------------------

	var data = [3,5,72,5,2];

	for(var i = 0; i < data.length; i++) {
		console.log(data[i]);
	}

	for(var i = 0; i < data.length; i++) {
		alert(data[i]);
	}

	-------

	functional style:

	function iterate(items, action) {
		for(var i = 0; i < items.length; i++) {
			action(items[i]);
		}
	}

	var data = [3,5,72,5,2];
	iterate(data, console.log);
	iterate(data, alert);
-------------
	High order functions [functions which return a function]

	var g = 100;

	function test() {
		var x = 10;

		function second() {
			var y = 15;

			console.log(x, y);
		}
	}

	-------------------------

	function greeting(msg, name) {
		return msg + " " + name;
	}

	greeting("Good morning", "Smith");
	greeting("Good morning", "Amy");
	greeting("Good morning", "Julia");
	------
	High order approach:
	
	function greeting(msg) {
		return function(name) {
			return msg + " " + name;
		}
	}

	var goodMorning = greeting("Good Morning");
	goodMorning("Julia"); // Good Morining Julia
	goodMorning("Roger");

	goodMorning; // function(name) { 	return msg + " " + name; 	}
----------------------------------------------------------------------
btn.addEventlistener("click", function(event) { });

------------------------------

	OOP with JavaScript

Different ways of creating Objects in JavaScript:
1) 
	var obj = new Object();
	obj.id = 10; // add state
	obj.name = "jim" ; // add state
	obj.doTask = function() {
		// code
	}

	console.log(obj.id);
	console.log(obj["id"]); // if attribute is dynamic

	var attr  = "id";
	console.log(obj[attr]); // if attribute is dynamic	

	obj.doTask();

2) 
	var nobj = Object.create(obj); // create nobj on top of obj [ Factory pattern]
	nobj.email = "me@adobe.com";


3) JSON
	JavaScript Object Notation

	var obj =  { };

	var department = 
		{
			"id" : 132,
			"name" : "accounts",
			"employees" : [
				{
				"id" : 1,
				"name" : "Raj"
				},
				{
				"id" : 2,
				"name" : "Rani"
				}
			]

		}

		department.name; // accounts
		department.employees[0].name; // Raj

4) Constructor Pattern
	
	function Book(id, name) {
		this.id = id;
		this.name = name;
	}

	var b1 = new Book(1,"Test");

	var b2 = new Book(2,"Rest");

	Adding behavior
	a) Object owned instance methods
		function Book(id, name) {
			this.id = id;
			this.name = name;
			this.getId = function() {
				return this.id;
			}
			this.getName = function() {
				return this.name;
			}
		}

	b) Class Owned instance methods
		function Book(id, name) {
			this.id = id;
			this.name = name;
		}

		Book.prototype.getId = function() {
				return this.id;
		}

		Book.prototype.getName = function() {
				return this.name;
		}

	c) Class owned class methods [ static ]

		Book.someTask = function() {
			// u can't use the context [ no "this" usage]
		}

--------------------

	function add(x, y) {
		return 
			x + y;
	}


	var res = add(4,2); 

	console.log(res);

-------------------------------------

var obj = {
	x : 10,
	first : function(action) {
		action();
	},
	second: function () {
		console.log(this.x);
	}
}

a)
var task = obj.second; //context is lost
obj.first(task);

b)

obj.first(obj.second.bind(obj));

var temp = {
	x : 1111
}
obj.first(obj.second.bind(temp));

----------

var obj = {
	x : 10,
	first : function(action) {
		action.call(obj);
	},
	second: function () {
		console.log(this.x);
	}
}

var task = obj.second; //context is lost
obj.first(task);

------------------------------------------

	JavaScript  Patterns:
	---------------------


	IIFE Immedietly invoke function expression [ Self invoking functions]

	(function() {
		// code
	})();

	1) Module Pattern
		used for encapsulation, introducing the concept 
		of visibility [ private , public ] in JS
	2) Factory Pattern
		to hide the complexity involved in creating the objects
		to hide the implementation from client

	3) Chain of Responsibilities
	4) Memoize Pattern
	5) Observable pattern
	6) Singleton

 
	Memoize Pattern [ Cache ]
	Chain of Responsibilities
		to delegate the job to next object in the chain

	var emp = { "id" :1,"name":"A"};


-----------------------------------------------------------------------------------------

ES -- ECMAScript 5 [ JavaScript version] supported by almost all the browser

New Version:
ES6 --- ES2015
Few browsers support partially

We use transpilers to convert Es6 - Es5 9 [Babel]

ES2015 [ Es6] features:
1) Support to block level variables and also constants

var g = 10; // global variable
const PI = 3.14159; // global constant

function test() {
	if(g > 5) {
		let x = 200;
		console.log(g, PI, x);
	}
	console.log(x); //error
}

2) New String literal

Old Way:

var name = "Smith";

var msg = "Hello " + name;

console.log(msg);

New Way:
var name = "Smith";

var msg = `
	Hello ${name}
	How are You
`;
console.log(msg);

3) Deconstructing arrays and objects

var colors = ["red","green","blue","orange","pink"];

old way:
var r = colors[0];
var g = colors[1];

New Way:
var [red,green,blue, ...others] = colors;

4) Arrow operator

Old Way:
function add(x, y) {
	return x + y;
}

E56:
	a) introduced default parameter values
	function add(x = 0, y= 0) {
		return x + y;
	}
	console.log(add(4,5));
	console.log(add());

	b) Arrow operator
	var sub = (x,y) => x -y;
	console.log(sub(24,5));
	--------
	function iterate(items, action) {
     	for (var i = 0; i < items.length; i++) {
        	 action(items[i], i);
     	}
	 }

 function map(items, mapperFn) {
     var result = [];
     iterate(items, function(data) {
         result.push(mapperFn(data));
     });
     return result;
 }

 --
  function map(items, mapperFn) {
     var result = [];
     iterate(items, (data) => {
         result.push(mapperFn(data));
     });
     return result;
  }

   var doubleIt = function(e) { return e * 2; }
    var result = map(elems, doubleIt);


    var result = map(elems, (e) => e*2);
 --------------------------------------------

 5) Promise API
 	Useful when invoking Asynchronous calls

 	a) Synchronous:

 		var data = doTask();
 		// blocked
 	b) ASynchronous:
 		doTask().then(function(data) {
 			//code
 		},
 		function(data) {
 			//code
 		});
------------------------------

 6) Es 6 introduced "class"

 	class Product {
 		constructor(id, name) {
 			this.id = id;
 			this.name = name;
 		}

 		getDetails() {
 			return this.id + ", " + this.name;
 		}
 	}

 	var p = new Product(13,"A");
 	console.log(p.getDetails());
------------------------------

7) ES 6 modules

	mylib.js

	export var date = new Date();

	export var smallDate = function(d) {
		// code
	}

	var somejunk = function() {

	}

	someother js file:
	import {date, smallDate} from './mylib';
	cosole.log(date);
	cosole.log(smallDate(new Date()));
-----------------------------------------------------------

	1) Install Node modules [ Libraries ]

	a) BOWER is client side library management tool
	npm install -g bower

	bower i --save jquery#2

	bower i --save bootstrap

	bower i --save underscore

	bower i --save jasmine#2

	bower i --save requirejs

---------------

	jQuery is a library for:
		1) DOM Manipulation
		2) DOM Traversing
		3) DOM Creation
		4) Simplifing AJAX calls

	JavaSCript:

		document.getElementById("idname");

		document.getElementByTagName("a");// gets all hyperlinks

		document.getElementByTagName("td");// gets all td
		document.querySelector(".class"); // not support in most of browser


		jQuery uses CSS selectors

		1)

		$("#listView")

			gets a element whose id is "listView"

		<div id="listView"></div>

		2)

			$(".del")

			gets all elements whose class is ".del"

			<button class="del">Delete</button>
			<button class="del">Delete</button>
			<button class="del">Delete</button>

		3) 
			$("button")
				gets all button elements 	


				---------

		jQuery for AJAX:
			AJAX => Asynchronus JavaScript API for XML

		Prior to JQUERY

		var xhr = new XMLHttpRequest();

		xhr.open("url");
		------------

		Prefer templates for generating views [ Complex views] 

Server Side Templates 							Client Side Templates
JSP 											Underscore
PHP 											HandleBars
EJS												Mustache
JADE								
ASP
ASP.NET
PUG
--------------------------------------------

	JS Unit Testing
	------------

	jasmine ---> Client Side code testing
	Mocha  ---> Server side code testing

	AAA ---> Assemble Action Assert


	describe("testing my modules", function (){
		//test spec
		it("should return a product", function() {
			// invoke
			//assert
		});
		//test spec
		it("should delete a product", function() {
			// invoke
			//assert
		});
	});
--------------------------------------------------------------

Module System:
a) JS module system
	(function() { })()

Asynchronous Module Defininition (AMD)
1) RequireJS
2) CommonJS

	model\product.js

	repo\productRepo.js

	main.js


bower install --save text