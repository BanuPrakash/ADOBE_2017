var g = 10; // global variable
const PI = 3.14159; // global constant

function test() {
	if (g > 5) {
		let x = 200;
		console.log(g, PI, x);
	}
	console.log(x); //error
}
