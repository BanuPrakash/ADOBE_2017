function doSomeTask() {
		return new Promise(function(resolve, reject) {
			setTimeout(function() {
				resolve("Employee information.....");
			}, 2000);
		});
};

function doSomeOtherTask(msg) {
		return new Promise(function(resolve, reject) {
			setTimeout(function() {
				resolve("OTHER TASK " + msg	);
			}, 2000);
		});
};

doSomeTask().then(doSomeOtherTask)
.then(function(data) {
	console.log("Success : " + data);
},
function(data) {
	console.log("ERROR : " + data);
});
