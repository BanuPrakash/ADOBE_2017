define(['../model/product'], function(Product) {
	var prds = [];

	function init() {
		prds.push ( new Product(1,"A"));
		prds.push ( new Product(2,"B"));
		prds.push ( new Product(3,"C"));
	}

	function getAll() {
		return prds;
	}

	return {
		"init" : init,
		"getAll" : getAll
	}
})