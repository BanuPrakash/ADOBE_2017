require.config({
	'baseUrl' : 'app',
	paths : {
		'jquery' : '../vendor/jquery/dist/jquery',
		'underscore' : '../vendor/underscore/underscore',
		'text' : '../vendor/text/text'
	}
});

// entry point code

require(['jquery','underscore','text!template/product.html','repo/productRepo'],
	function($,_,templ, repo){
		var compiledTemplate = _.template(templ);
		repo.init();
		var rendered = compiledTemplate({"products": repo.getAll()});
		$(document.body).html(rendered);
});