function add(x, y) {
    return x + y;
}


function iterate(items, action) {
 
     for (var i = 0; i < items.length; i++) {
         action(items[i], i);
          
     }
 }

 function map(items, mapperFn) {
     var result = [];
     iterate(items, function(data) {
         result.push(mapperFn(data));
     });
     return result;
 }

 function filter(items, predicate) {
    var result = [];
     iterate(items, function(data) {
        if(predicate(data)) {
            result.push(data);
        }
     });
     return result;
 }