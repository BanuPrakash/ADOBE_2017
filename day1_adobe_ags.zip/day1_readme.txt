
Web Technologies
----------------
Banu Prakash C
banuprakashc@yahoo.co.in
banu@advantech-global.comJavaScript is a scripting language , loosely typed

ES5 ECMA 5
ES6 ES2015 ECMA 6
ES 7 ES 2017 ( NExt version)

banu@lucidatechnologies.com
---------------------------------

	Chrome Browser
	Sublime Text

	JavaScript + HTML + CSS

	--------------------------

	JavaScript is a scripting language , loosely typed

	ES5 ECMA 5
	ES6 ES2015 ECMA 6
	ES 7 ES 2017 ( NExt version)

	"var" is the keyword to explicitly declare a variable, there is no concept of 
	constants in JS - ES 5

	var name = "Smith";

	var age = 28;

	var employed = true;

	-----------

		JS executes in JavaScript engines

		V8 ---> google -=-> Chrome and Node JS env
		SpiderMonkey ===> Firefox  and Adobe products
		Chakra ---> MS ---> IE
		Continnum ---> MS ---> Edge
		NashHorn ---> Oracle/ Sun ---> all oracle products

	----------------
	
		Understanding Scopes in JS:

		first.js

		var g = 100;

		function doTask() {
			var first = 10;
				if( g > first) {
					var second = 20; // hoisting [ second is pushed to fn scope]
					third = 30; // hoisted to global scope
				}
		console.log(g, first, second, third);
		}		

		doTask();
		console.log(g, first, second, third); // g and third are visible
	-----------------------------

		Functions:

		function doTask() {

		}

		or

		var doTask = function() {

		}

		---------------------------------

		function add(x, y) {
			var result = x  + y;
		}

		console.log(add(4,5)); // undefined
------------------

		function add(x, y) {
			var result = x  + y;
			return result;
		}

		console.log(add(4,5)); // 9
	-------------------
	function add(x, y) {
			return x  + y;
		}

		console.log(add(4,5)); // 9
	---------------------
	function add(x, y) {
			return 
				(x  + y);
	}

	console.log(add(4,5)); // undefined
 -------------------------------------------
 	OOP with JS

 	Different ways of creating Objects in JS:

 	1) 
 	var obj = new Object();

 	obj.id = 10;
 	obj.name = "Tim";

 	obj.getDetails = function() {
 		return this.id + ", " + this.name;
 	}

 	obj.getDetails();

 	var obj2 = obj;

 	var obj3 = Object.create(obj); // clone

 	2)

 		Constructor Pattern

 		function Employee(id, name ){
 			this.id = id;
 			this.name = name;
 			this.getId = function() {
 				return this.id;
 			}

 			this.getName = function() {
 				return this.name;
 			}
 		}


 		var e1 = new Employee(1,"A");
 		var e2 = new Employee(2,"B");

 		e1.getName();
 		e2.getName();

 		-----------

 		function Employee(id, name ){
 			this.id = id;
 			this.name = name;
 		}
 		Employee.prototype.getId = function() {
 				return this.id;
 			}

 		Employee.prototype.getName = function() {
 				return this.name;
 			}

 		var e1 = new Employee(1,"A");
 		var e2 = new Employee(2,"B");

 		e1.getName();
 		e2.getName();
 -------------------------------------------------------------

 	3) JSON
 		JavaScript Object Notation

 		STD for RESTful Web services

 		Representational State Transfer

 		CSV, XML, JSON

 		EMP
 		EMP_ID | ENAME | JOB | HIREDATE

 		100    SMITH  MANAGER  10-JUN-1970
 		101    ALLEN  ACCOUNTS 12-APR-1999


 		CSV
 			100, SMITH, MANAGER, 10-JUN-1970

 		XML
 			<employees>
 				<employee>
 					<id>100</id>
 					<ename>SMITH</ename>
 					<hiredate>10-JUN-1970</hiredate>
 				</employee>
 				<employee>
 					///
 				</employee>
 			</employees>

 	JSON --> B2B as well as B2C


 	JSON :

 	 Object is represented as 	{}

 	 Object contains key/ value pair

 	 	var obj = {
 	 		id : 1,
 	 		name: 'Smith',
 	 		getDetails : function() {
 	 			return this.id + ", " + this.name;
 	 		}

 	 	};

 	------------------------------------------------
 	
 	Functional Style of Programming
 		using High Order functions:

 		High order functions are functions which accept other functions as arguments
 		or returns a function.


 		In JS functions are first class members just like primitives and objects

 	Simple example:

 		var data = [45,22,66,22,1];

 		Traditional approach:
 		for(var i = 0; i < data.length; i++) {
 			console.log(data[i]);
 		} 	

 		for(var i = 0; i < data.length; i++) {
 			alert(data[i]);
 		} 

 		for(var i = 0; i < data.length; i++) {
 			writeToFile(data[i]);
 		} 

 	 --------

 	 High Order functional style

 	 	var data = [45,22,66,22,1];

 	 	function iterate(elems, action) {
 	 		for(var i = 0; i < elems.length; i++) {
 				action(data[i]);
 			} 
 	 	}

 	 	iterate(data, console.log);
 	 	iterate(data, alert);
 	 	iterate(data, writeToFile);

 	 -----------

 	 normal usages of high order functions:
 	 	a) MAP
 	 	b) FILTER
 	 	c) REDUCE
 	 	d) SORT
 	 	e) ITERATE
--------------------------------------------

	IIFE ->Self Invoking functions

	Immedietly invoke function expression

	(function() {

	})();

	IIFE can be used for module pattern.

	Module Pattern can be used to provide proper encapsulation

	// Product Module
	(function() {
		var data;
		function getDetails() {

		}

		function addDetails() {

		}

		return {
			get: getDetails,
			add: addDetails
		}
	})();


	// customer module
	(function() {
		var data;
		function getDetails() {

		}

		function addDetails() {

		}
	})();


	---------

	Observer - Observable Pattern 

	npm install -g javascripting
	npm install -g functional-javascript-workshop
--------------------------------------------------------------

	ES 6 Features:

	1) Block level scope and constants

	first.js

	var g = 100;
	const PI = 3.14159;

		function doTask() {
			var first = 10;
				if( g > first) {
					let second = 20; // block scope
					third = 30; // hoisted to global scope
				}
		console.log(g, first, second, third); // second is not visible
		}		

		doTask();
		console.log(g, first, second, third); // g and third are visible

	2) New String Literal
		Prior to ES2015/ 6 we had "" and '' for string literal

		New String literal ``

		Advantages:

		var name = "Adobe Blr";

		var sentence = `
			Welcome to ${name},
			Training on JS `;

	3) Deconstructing

		var colors = ["red","green","blue","orange","pink"];

		old way:
		var r = colors[0];

		New Way:
		var [r,g,b,others] = colors;

	4) Arrow Operator:

		Old Way:

		var add = function (x, y) {
			return x + y;
		}

		New Way:
		var sub = (x,y) => x - y;

		var sub = (x,y = 0) => {
			var result = x - y;
			return result;
		}

	5) class type

		class Employee {
			constructor(id, name) {
				this.id = id;
				this.name = name;
			}

			getDetails() {
				return this.id + ", "  + this.name;
			}
		}

		let e1 = new Employee(1,"A");
		console.log(e1.getDetails());


	6) Promise API for Asynchronous calls

		Server Side Code

		doTask() {
			// code
		}

		If Sync:

		var result = doTask();
		// some other code


		Async:

		doTask().then(function(data){

		}, function(err){

		});

		//some other code

		