function iterate(elems, action) {
		for(var i = 0; i < elems.length; i++) {
 				action(elems[i]);
 		} 
}

function map(elems, mappingFn) {
	var result = [];
	iterate(elems, function(v) {
		result.push(mappingFn(v));
	});
	return result;
}

function filter(elems, predicate) {
	var result = [];
	iterate(elems, function(v) {
		if(predicate(v)) {
			result.push(v);
		}
	});
	return result;
}