 function doTask() {
 	return new Promise( (resolve, reject) => {
 		setTimeout(function(){
 			reject("My BAD ;-(");
 		}, 1000);
 	});
 }


// client code

doTask().then(function(data){
	console.log("RESOLVED " + data);
}, function(err){
	console.log("REJECTED " + err);
});

